import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";

app.disable("x-powered-by");
// اجازه‌ی درخواست از اپ اندروید Capacitor و دامنه‌ی وب تنظیم‌شده
const allowedOrigins = new Set([
  "http://localhost", "https://localhost", "capacitor://localhost",
  ...(process.env.APP_ORIGIN ? process.env.APP_ORIGIN.split(",").map(x => x.trim()) : [])
]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: "12mb" }));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "تعداد درخواست‌ها زیاد است. کمی بعد دوباره امتحان کن.", code: "rate_limited" }
}));

app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return res.status(503).json({
    error: "کلید API روی سرور تنظیم نشده است.", code: "missing_key"
  });

  const messages = Array.isArray(req.body?.messages) ? req.body.messages.slice(-10) : [];
  const instructions = typeof req.body?.instructions === "string"
    ? req.body.instructions.slice(0, 12000)
    : "به فارسی و متناسب با پرسش دانش‌آموز پاسخ بده.";

  if (!messages.length) return res.status(400).json({
    error: "پیامی برای پاسخ وجود ندارد.", code: "bad_request"
  });

  const input = messages.map((message) => {
    const role = message.role === "assistant" ? "assistant" : "user";
    if (typeof message.content === "string") return { role, content: message.content };

    const content = [];
    if (Array.isArray(message.content)) {
      for (const part of message.content) {
        if (part?.type === "text" && typeof part.text === "string") {
          content.push({ type: "input_text", text: part.text });
        } else if (part?.type === "image" && part.source?.type === "base64"
          && typeof part.source.data === "string"
          && ["image/jpeg", "image/png", "image/webp", "image/gif"].includes(part.source.media_type)) {
          content.push({
            type: "input_image",
            image_url: `data:${part.source.media_type};base64,${part.source.data}`
          });
        }
      }
    }
    return { role, content };
  }).filter(item => typeof item.content === "string" || item.content?.length);

  if (!input.length) return res.status(400).json({
    error: "متن پیام قابل پردازش نیست.", code: "bad_request"
  });

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        instructions,
        input,
        max_output_tokens: 1100,
        store: false
      }),
      signal: AbortSignal.timeout(60000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("OpenAI API error:", upstream.status, data?.error?.code || data?.error?.type || "unknown");
      return res.status(upstream.status === 429 ? 429 : 502).json({
        error: upstream.status === 429
          ? "محدودیت موقت درخواست یا اعتبار API رخ داده است."
          : "سرویس هوش مصنوعی پاسخ نداد. تنظیمات سرور و دسترسی API را بررسی کن.",
        code: upstream.status === 429 ? "rate_limited" : "upstream_error"
      });
    }

    const text = typeof data.output_text === "string" ? data.output_text : "";
    if (!text.trim()) return res.status(502).json({
      error: "پاسخ متنی دریافت نشد.", code: "empty_response"
    });
    res.json({ text });
  } catch (error) {
    console.error("Chat request failed:", error?.name || "Error");
    res.status(502).json({
      error: "ارتباط با سرویس هوش مصنوعی برقرار نشد.", code: "upstream_error"
    });
  }
});

app.use(express.static(__dirname));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.listen(PORT, () => console.log(`برنامه کنکور روی http://localhost:${PORT} اجرا شد`));
