/* آدرس سرور بک‌اند را بعد از استقرار اینجا وارد کن.
   نمونه: https://konkur-api.example.com
   اسلش انتهای آدرس لازم نیست. کلید OpenAI را هرگز اینجا قرار نده. */
window.KONKUR_API_BASE_URL = "https://YOUR-BACKEND-DOMAIN";
